import UIKit

 var sponsors = ["adidas", "Estée Lauder", "Carolina Herrera Good Girl", "Apple", "WeWork"]

//write a for-in loop for an array
for sponsor in sponsors { //If we see "for-in" this is a loop in Swift
    //sponsor is like a counter
    //five elements in sponser means it will execute the code five times
    print(" Thank you to \(sponsor) for helping me make KWK happen!")
}


var capitals = ["France": "Paris",
                "Cuba": "Havana",
                "Japan":"Tokyo"
]
//Elements- are the groupings (characterization, key value pair), keys- are the countries, values- are the cities
// a loop that iterates each ELEMENT of the dictionary
for pair in capitals{
    print(pair)
    
}
// a loop that specifically prints each key and value seperatley

for (country, cities) in capitals{
    print("The capital of \(country) is \(cities)!")
    
    
}



/*
var names = ["Lucy",
             "Bailey",
            "Alice",
            "Emma",
            "Sally"
]

for x in names {
print("Hello,\(x)")
    
}

var capitals = ["8 miles": "Paris",
                "40 miles": "Havana",
                "800 miles":"Tokyo"

]

for (y,x) in capitals {
print("You are currently \(y) from \(x)")
}
*/

//another loop that specifically prints each key and value seperatley
for pair in capitals{
    print("The capital of \(pair.key) is \(pair.value)!")
    //if you only want one element make it singular
}
for _ in 1...4{
    print("Hello World!")
}

}
for _ in 10...17{
    print("Hello World!")
}

