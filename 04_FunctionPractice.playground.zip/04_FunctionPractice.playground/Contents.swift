import UIKit

func makeBreakfast() {
    print("make pancakes")
    print("cook some bacon")
    print("cut some fruit")
    print("make scrambled eggs")
    print("thank you!")
    
}
makeBreakfast()

func makeBed() {
    print("clean sheets ")
    print("put on bed")
    print("thank you!")
    
}
makeBed()

func cleanCar() {
    print("get soap")
    print("get water")
    print("shine the car")
    print("thank you!")
    
}
cleanCar()



func waterPlants(numberOfPlants : Int) -> Int {
    let amountOfwater = numberOfPlants * 15
    return amountOfwater
    print("grab the hose")
    print("ensure all plants have water")
    print("thank you!")
}
waterPlants(numberOfPlants: 6)






/* func waterPlants() {
    print("grab the hose")
    print("ensure all plants have water")
    print("thank you!")
/*


