import UIKit

func walkDog() {
    print("Grab the leash")
    print("Put the leash on the dog")
    print("Open the door")
    print("Go outside")
}
walkDog()

func makeCereal() {
    print("get milk")
    print("get some cereal")
    print("get a bowl and spoon ")
    print("put cereal in the bowl and pour milk")
    print("enjoy!")
    
}
makeCereal()

func sendText () {
    print("obtain a phone")
    print("get the desired number")
    print("say hello!")
    print("have fun lol")
}
sendText()

func walkDog(numberOfDogs : Int) {
    print("Grab the leash")
    print("Put the leash on the dog")
    print("Open the door")
    print("Go outside")
    print("Do this \(numberOfDogs) times")

    
/* }
walkDog(numberOfDogs: 3)

func Hello(personName : String) {
    print(" Hello \(personName)!")
    
}

Hello(personName: "Camille")


func walkDogs)walkDog(numberOfDogs: <#T##Int#>)Int {
    var numberOfPoopBags = numberOfDogs * 3
    return numberOfPoopBags
}

var totalCost = walkDog(numberOfDogs : 3) * 3
print(totalCost)
walkDog(numberOfDogs: 3)
*/


    func walkDogs(numberOfDogs : Int) -> Int {
        let lengthOfWalk = numberOfDogs * 15
        return lengthOfWalk
    }
    
    walkDogs(numberOfDogs: 3)

