/*
//Intention : this playground tests different comparison operators
6<7
18<10

//<= less than or equal to
//true
//false

7 <= 6+1
7 <= 3

//>= greater than or equal to
//true
//false

11 <= 9
9 <= 12


//test the == operator
//use only one equal SIGN TO SET THE VALUE TO SOMETHING
//ex) number = 10
//use == to check if two things are equal

12 == 10 + 2

//test the != operator
12 != 10+2




//check what && does
12 == 10 + 2 && 12 == 6+6
12 == 10 + 2 //true
12 == 6 + 6// true

12 == 10+2 && 12 == 10+10
// the && checks if both sides are true, if they are, it returns to true



//check what || means ----> or
12 == 10+2 //true
12==10+10 //false
12 == 10+2 || 12==10+10 //left is true but thr right is false
1+2==1 || 1+2==2

5<3
12>7
6 != 8
7 == "7"
"karlie" == "karlie"
"karlie" == "karliekloss"
var luckyNum = 7
luckyNum < 10
luckyNum == 7
*/
 
//declaring an if statement
var dogAge = 1
if dogAge < 2 { //checking if dog age is less than 2 which is a true statement
    print("You are a puppy 🐶") //if the condition check is true, then do this code
}

if dogAge == 2 {
    print("You are awesome!")
}


var favoriteFood = "sushi"
if favoriteFood == "Chipotle"
{
    print ("Your favorite food is Chipotle? Really?")
}


else if  favoriteFood == "fried chicken"
{
    print ("Ew fried chicken is gross!")
}



