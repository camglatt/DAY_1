import UIKit

//Example of class and objects

//code between lines 6-10 is the class
/*
class Can {
    let containerType = "Can"
    let containerSize = "Small"
    let containerCap = "White"
}

var containerColor : String ()

init(color : String) {
    containerColor = color
}

var cannedPeaches = Can (color :"Blue")
print(cannedPeaches.containerType)
print(cannedPeaches.containerSize)
print(cannedPeaches.containerCap)
print(cannedPeaches.containerColor)

// This code is the object
var cannedPeaches = Can()

class Can {
    let containerType = "Can"
    var labelColor = String
    init(color: String) {
        labelColor = Color
    }
    
}
var cannedPeaches = Can(color : "light orange")

class nycScholar {
    let computerType = "Apple"
    let language = "English"
    let gender = "female"
}

var Scholar = nycScholar ()
print(Scholar)
print(Scholar.computerType)
print(Scholar.gender)
print(Scholar.language)


//this is the code for the class

class Can {
    let containerType = "Can"
    var stuffInside : String
    
    init(fruit:String) {
        stuffInside = fruit
        
    }
}
//this si the code for the object

var cannedPeaches = Can(fruit : "peaches")

print(cannedPeaches)
print(cannedPeaches.containerType)
print(cannedPeaches.stuffInside)


class Can {
    let containerType = "can"
    var stuffInside : String
    
    init(fruit:String) {
        stuffInside = fruit
        
    }
    func description() {
        print("\(stuffInside) are packed inside this \(containerType)")
    }
    func description2() {
        print("\(stuffInside) are good for you")
}
}
//this is the code for the object

var cannedPeaches = Can(fruit : "Raspberries")


//the code on these lines is printing properties of our object (can, packed)
print(cannedPeaches)
print(cannedPeaches.containerType)
print(cannedPeaches.stuffInside)

cannedPeaches.description() //this is calling the action/method/function to print within the object
cannedPeaches.description2()

*/



class Can {
    let containerType = "box"
    var stuffInside : String
    
    init(powder:String) {
    
    stuffInside = powder
        
    }
    func description() {
        print("\(stuffInside) is packed inside this \(containerType)")
    }
    func description2(numberOfFruit : Int) {
        print("\(numberOfFruit) \(stuffInside) is bad for you")
    }
}

var cannedPeaches = Can(powder : "Flour")
        print(cannedPeaches)
        print(cannedPeaches.containerType)
        print(cannedPeaches.stuffInside)
        
        cannedPeaches.description() //this is calling the action/method/function to print within the object
        cannedPeaches.description2(numberOfFruit: 3)




