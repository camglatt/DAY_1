import UIKit

/*
//This is a playground for colletions
//Initialize an array

var ArrayofStrings = [String] ()
var ArrayofIntegers = [Int] ()

//An array that stores the numbers 0,1,2,3,4
var numbers = [0,1,2,3,4]

//This array stores four elements which are strings
//quotations are for strings not for print
var friendsOfKarlie = ["Michelle Obama", "Serena Williams", "Taylor Swift", "Jimmy Fallon"]
print(friendsOfKarlie)  //prints entire Array
print(friendsOfKarlie[1]) //prints serena williams because you start from index of zero - location in an Array
print(friendsOfKarlie[3]) //prints jimmy fallon
friendsOfKarlie[2] = "Josh Kushner" //this will replace taylor with josh
print(friendsOfKarlie[2])
print(friendsOfKarlie)
//adding informatuon in an Array
friendsOfKarlie.append("Taylor Swift") //should be stored at location four
print(friendsOfKarlie)
// append automatically adds to the end of an Array
//challenge: how do I add in a specific location in an Array
// removing information in an Array
friendsOfKarlie.remove(at: 3)
print(friendsOfKarlie)


 
 

 var friendsOfCamille = ["Allegra Williams", "Zane Smith", "Ellie Shilling", "Anne Brown"]
 print(friendsOfCamille[3])
print(friendsOfCamille)
friendsOfCamille[1] = "Gabriella Hu"
print(friendsOfCamille)
friendsOfCamille.append("Zane Smith")
friendsOfCamille.remove(at: 0)
*/

//initialize an empty dictionary
var scholarsFavColor : [String:String] = [:]
scholarsFavColor = [
    "Kaitlyn":"Blue",
    "Micah":"Blue",
    "Audrey":"Purple",
    "Cheyenne":"Yellow"
]

print(scholarsFavColor)
//if you want to print a particular persons favorite color - for example: print Audreys favorite color
print(scholarsFavColor["Audrey"]) //prints Optional("Purple")
print(scholarsFavColor["Brooke"]) // prints nil or no data found
print(scholarsFavColor["Audrey"]!) //tells Swift that there is data there
/*
print(scholarsFavColor["Brooke"]!) //this will give me an error becayse there is not data for Brooke even though I said there was by writing the exclamation point
*/

var familyBirthday : [String:String] = [:]
familyBirthday = [
    "Charlotte":"December 20",
    "Carter":"May 21",
    "Barbara":"Novemeber 2",
    "Alan":"August 31",
    "Boba":"May 6",
    "Dash":"April 4",
    "Poppop":"April 21",
    "Omi":"July 11",
    "Ellie":"August 9",
    "Zane":"October 18th"

]

print(familyBirthday)

print(familyBirthday["Zane"]!)
print(familyBirthday["Barbara"]!)
print(familyBirthday["Alan"]!)


