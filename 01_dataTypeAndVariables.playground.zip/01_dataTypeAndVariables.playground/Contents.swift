/*import UIKit
var first = "Karlie"
var last = "Kloss"
let string1 = "Karlie"
let string2 = "Kloss"
var KarlieKloss = string1 + "" + string2
var karliekloss1 = "Hello, My name is" + "" + string1 + string2
var first = "I love"
var lirst = "karlie"
let string1 = "I love"
let string2 = "Karlie"
var ILoveKarlie = string1 + " " + string2





print("KarlieKloss")
print("KlossKarlie")
print("Karlie Kloss")
print("kloss karlie kloss karlie")
print("I love karlie")
 another statement
*/

/*var integer = 4.0
var double = 5.0
integer*double
 


var a = 12.0
var b = 65.0
var c = 31.0
var d = 98.0

(a + b + c + d)/4

(a + b) + c + d/4

a + b + c / d
 */

/* var a = 10.25
var b =  20.0

(a*b)
*/


var first = "Happy Birthday"
var second = "Camille"
let string1 = "Happy Birthday"
let string2 = "Camille"
var HappyBirthdayCamille = "string1 + "" + string2"
